#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f10x.h"             

/*����Ĳ����ṹ��*/
typedef struct{
	int16_t	 	speed_rpm;   		
    int16_t  	real_current;		
    int16_t  	given_current;	   	
    int8_t  	hall;
	int16_t 	angle;				//abs angle range:[0,8191]
	int16_t 	last_angle;			//abs angle range:[0,8191]
	int16_t	offset_angle;
	int32_t		round_cnt;
	uint32_t		total_angle;
	u8			buf_idx;
	u16			fited_angle;
	u32			msg_cnt;
}moto_measure_t;  

uint8_t get_moto_measure(moto_measure_t *ptr, CanRxMsg* CAN_Rece_Data); //��ȡ������ĵ���ֵ
void CAN1_Send(int16_t i1,int16_t i2,int16_t i3,int16_t i4);//��c620������͵�ֵ
void CAN1_Set(CanRxMsg* CAN_Rece_Data);//�����ֵ
extern moto_measure_t motor_chassis;//����ײ����
typedef struct{
	float kp;
	float ki;
	float kd;
	float kpv;
	float kiv;
	float kdv;
} motorPara_t;
extern motorPara_t motorPara;

#endif
