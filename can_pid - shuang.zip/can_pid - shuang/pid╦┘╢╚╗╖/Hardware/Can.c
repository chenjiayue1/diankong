#include "Can.h"
#include "motor.h"
#include "pid.h"

extern CanRxMsg  CAN_Rece_Data;


void CAN_GPIO_Init(void)
{
	//����GPIOʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);
	
	//	�������ŵĵڶ�����
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig (GPIO_Remap1_CAN1,ENABLE);
	
	
	
	//����GPIO����
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU ;		//��������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;          //CAN_Rx����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;		//�����������
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;			//CAN_Tx����
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	
}


void CAN_Mode_Init(void)
{
	//ʹ��CANʱ��
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);
	
	//����CAN�Ĺ���ģʽ
	CAN_DeInit(CAN1);
	CAN_InitTypeDef CAN_InitStructure;
    CAN_InitStructure.CAN_ABOM = DISABLE;
	CAN_InitStructure.CAN_AWUM = DISABLE;
	CAN_InitStructure.CAN_Mode = CAN_Mode_Normal; //����ģʽ
	CAN_InitStructure.CAN_NART = ENABLE; //�����ش�
	CAN_InitStructure.CAN_RFLM =DISABLE ;
	CAN_InitStructure.CAN_TTCM = DISABLE;
	CAN_InitStructure.CAN_TXFP = DISABLE; //ID���ȼ�����
	
	//���ó�1Mbps
	CAN_InitStructure.CAN_BS1 = CAN_BS1_5tq;
	CAN_InitStructure.CAN_BS2 = CAN_BS2_3tq;
	CAN_InitStructure.CAN_SJW = CAN_SJW_2tq;
	CAN_InitStructure.CAN_Prescaler = 4;
	
	CAN_Init(CAN1,&CAN_InitStructure);
	
}

//���ù�����
void CAN_Filter_Init(void)
{
	CAN_FilterInitTypeDef CAN_FilterInitStruct;
	CAN_FilterInitStruct.CAN_FilterActivation = ENABLE;
	CAN_FilterInitStruct.CAN_FilterFIFOAssignment = CAN_Filter_FIFO0;
	CAN_FilterInitStruct.CAN_FilterIdHigh = 0X0000;//��׼֡&����֡
	CAN_FilterInitStruct.CAN_FilterIdLow =  0x0000;
	CAN_FilterInitStruct.CAN_FilterMaskIdHigh = 0x0000;
	CAN_FilterInitStruct.CAN_FilterMaskIdLow = 0x0000;
	CAN_FilterInitStruct.CAN_FilterMode = CAN_FilterMode_IdMask;	//�б�ģʽ
	CAN_FilterInitStruct.CAN_FilterNumber = 0;						//��������0
	CAN_FilterInitStruct.CAN_FilterScale = CAN_FilterScale_32bit;	//32λɨ��

	CAN_FilterInit(&CAN_FilterInitStruct);
	
	CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);  //�����ж��ó�FIFO������
	CAN_ClearITPendingBit(CAN1,CAN_IT_FF0);
}


//�ж�����
void CAN_NVIC_Config(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;//����NVICͨ��
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;	
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
 
	NVIC_Init(&NVIC_InitStructure);
}



void CAN_Config(void)
{
	 CAN_GPIO_Init();
	CAN_Mode_Init();
	CAN_Filter_Init();
	CAN_NVIC_Config();

}

