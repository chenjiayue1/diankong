#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "motor.h"
#include "Can.h"
#include "pid.h"


    extern moto_measure_t motor_chassis;
    CanRxMsg  CAN_Rece_Data;
	pid_t pid_speed;
	pid_t pid_position;	//�������PID��
//	float Kp =5.0;
//	float Ki =5.0;
//	float Kd =1.0;
	uint32_t maxout=1000;
	uint32_t intergral_limit=1000;
	// float set_speed = 100; //�ٶ��趨ֵ
	 float set_position = 500;
	int16_t i1,i2,i3,i4;
	float i;
	int16_t posout;
	//int16_t i1;
	
	
	




int main(void)
{
	 CAN_Config();
	

	PID_struct_init(&pid_speed,POSITION_PID,maxout,intergral_limit, 1.0f, 0.0f,0.5f);
	PID_struct_init(&pid_position, POSITION_PID, maxout,intergral_limit,1.0f,0.0f, 0.5f);   																																										 
	 	
	while (1)
	{
	}
}

void USB_LP_CAN1_RX0_IRQHandler()
{
	if (CAN_GetITStatus(CAN1,CAN_IT_FMP0)!=RESET)//����Ƿ����䷢���ж�
	{
		
		CAN_Receive(CAN1,CAN_FIFO0,&CAN_Rece_Data);//����can�յ��ĺ���

		switch (CAN_Rece_Data.StdId)
		{
			case 0x201://���id��Ϊ1��������Ϣ
			
			{
				get_moto_measure(&motor_chassis, &CAN_Rece_Data);//���µ���Ĳ���
				break ;
			}	
			default:
			{
				break ;
			}
		}
				CAN_ClearITPendingBit(CAN1,CAN_IT_FF0);//����жϱ�־λ

	}
  

        i = pid_calc(&pid_speed,(float)motor_chassis.angle, set_position );

          posout  = pid_calc(&pid_speed,(float)motor_chassis.speed_rpm, i);
	  


	CAN1_Send(posout,i2,i3,i4);


}

/*pid_calc(&pid_position[i], (float)moto_chassis[i].total_angle, set_position[i]);
				// �ٶȻ�
				pid_calc(&pid_speed[i], (float)moto_chassis[i].speed_rpm, pid_position[i].pos_out);
			}
			
			set_moto_current(&CAN1_Handler, 0x200, (s16)(pid_speed[0].pos_out),
							 (s16)(pid_speed[1].pos_out),
							 (s16)(pid_speed[2].pos_out),
							 (s16)(pid_speed[3].pos_out));
*/
/*
now_speed=motor_chassis.speed_rpm;
            now_position+=now_speed;
            pwm=p_pid(now_position,tar_psoition);
            pwm=limit(pwm,tar_speed);
			if(myabs(tar_psoition-now_position)<5)
				left(0);


static void abs_limit(float *x,int32_t limit)//�޷�
{
	if(*x > limit)
		*x = limit;
	if(*x < -limit)
		*x = -limit;
}
*/
//i1=(int16_t) pid_calc(&pid_position,motor_chassis.total_angle, set_position);
				
	//pid_calc(&pid_speed,motor_chassis.speed_rpm, i1);
//	now_speed=motor_chassis.speed_rpm;
//            now_position+=now_speed;
//	
//	if (myabs((int16_t)set_position - now_position) < 50) {
//    pid_calc(&pid_speed, motor_chassis.speed_rpm, 0); // ���ֹͣ
