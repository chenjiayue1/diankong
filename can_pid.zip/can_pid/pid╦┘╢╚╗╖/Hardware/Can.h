#ifndef __CAN_H
#define __CAN_H

#include "stm32f10x.h"             

void CAN_Config(void);



#endif

