#include "stm32f10x.h"                  // Device header
#include "reg52.h"
sbit LED1=P2^0; //将 P2.0 管脚定义为 LED1

void main() {
    LED1=0; //LED1 端口设置为低电平，就会被点亮
    while(1) {
        //单片机默认不断执行主程序。如果没有这个死循环，单片机就会不断点亮点亮点亮点亮……不如点亮一次之后无限延时。
    }
}