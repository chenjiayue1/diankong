#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "CountSensor.h"
#include "LED.h"
#include "Key.h"

int main(void)
{
	uint8_t KeyNum;
	
	CountSensor_Init();
	LED_Init();
	Key_Init();
	
	
	while (1)
	{
		KeyNum = KeyNum_Get();
		
		if (KeyNum == 2)
		{
			LED2_Turn();
		}
	}
		
		
	}

